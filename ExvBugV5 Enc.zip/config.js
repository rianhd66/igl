const global = {
owner: "7258699819", // ganti jadi id mu
ch: "-1002317029370", // ganti jadi id mu
botToken: "-", //isi make token bot mu
}

module.exports = global;